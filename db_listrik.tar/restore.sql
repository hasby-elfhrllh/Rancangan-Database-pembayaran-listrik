--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_tarif DROP CONSTRAINT tb_tarif_pkey;
ALTER TABLE ONLY public.tb_tagihan DROP CONSTRAINT tb_tagihan_pkey;
ALTER TABLE ONLY public.tb_penggunaan DROP CONSTRAINT tb_penggunaan_pkey;
ALTER TABLE ONLY public.tb_pembayaran DROP CONSTRAINT tb_pembayaran_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_admin DROP CONSTRAINT tb_admin_pkey;
ALTER TABLE public.tb_tarif ALTER COLUMN id_tarif DROP DEFAULT;
ALTER TABLE public.tb_tagihan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tb_tagihan ALTER COLUMN id_penggunaan DROP DEFAULT;
ALTER TABLE public.tb_tagihan ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.tb_penggunaan ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tb_penggunaan ALTER COLUMN id_penggunaan DROP DEFAULT;
ALTER TABLE public.tb_pembayaran ALTER COLUMN id_admin DROP DEFAULT;
ALTER TABLE public.tb_pembayaran ALTER COLUMN id_pelanggan DROP DEFAULT;
ALTER TABLE public.tb_pembayaran ALTER COLUMN id_tagihan DROP DEFAULT;
ALTER TABLE public.tb_pembayaran ALTER COLUMN id_pembayaran DROP DEFAULT;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_admin ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_admin ALTER COLUMN id_admin DROP DEFAULT;
DROP SEQUENCE public.tb_tarif_id_tarif_seq;
DROP TABLE public.tb_tarif;
DROP SEQUENCE public.tb_tagihan_id_tagihan_seq;
DROP SEQUENCE public.tb_tagihan_id_penggunaan_seq;
DROP SEQUENCE public.tb_tagihan_id_pelanggan_seq;
DROP TABLE public.tb_tagihan;
DROP SEQUENCE public.tb_penggunaan_id_penggunaan_seq;
DROP SEQUENCE public.tb_penggunaan_id_pelanggan_seq;
DROP TABLE public.tb_penggunaan;
DROP SEQUENCE public.tb_pembayaran_id_tagihan_seq;
DROP SEQUENCE public.tb_pembayaran_id_pembayaran_seq;
DROP SEQUENCE public.tb_pembayaran_id_pelanggan_seq;
DROP SEQUENCE public.tb_pembayaran_id_admin_seq;
DROP TABLE public.tb_pembayaran;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP SEQUENCE public.tb_admin_id_level_seq;
DROP SEQUENCE public.tb_admin_id_admin_seq;
DROP TABLE public.tb_admin;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin integer NOT NULL,
    username character varying,
    password character varying,
    nama_admin character varying,
    id_level integer NOT NULL
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_admin_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_admin_id_admin_seq OWNER TO postgres;

--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_admin_id_admin_seq OWNED BY tb_admin.id_admin;


--
-- Name: tb_admin_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_admin_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_admin_id_level_seq OWNER TO postgres;

--
-- Name: tb_admin_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_admin_id_level_seq OWNED BY tb_admin.id_level;


--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: tb_pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pembayaran (
    id_pembayaran integer NOT NULL,
    id_tagihan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    tanggal_pembayaran date,
    bulan_bayar integer,
    biaya_admin integer,
    total_bayar integer,
    id_admin integer NOT NULL
);


ALTER TABLE tb_pembayaran OWNER TO postgres;

--
-- Name: tb_pembayaran_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pembayaran_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pembayaran_id_admin_seq OWNER TO postgres;

--
-- Name: tb_pembayaran_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pembayaran_id_admin_seq OWNED BY tb_pembayaran.id_admin;


--
-- Name: tb_pembayaran_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pembayaran_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pembayaran_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tb_pembayaran_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pembayaran_id_pelanggan_seq OWNED BY tb_pembayaran.id_pelanggan;


--
-- Name: tb_pembayaran_id_pembayaran_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pembayaran_id_pembayaran_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pembayaran_id_pembayaran_seq OWNER TO postgres;

--
-- Name: tb_pembayaran_id_pembayaran_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pembayaran_id_pembayaran_seq OWNED BY tb_pembayaran.id_pembayaran;


--
-- Name: tb_pembayaran_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pembayaran_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pembayaran_id_tagihan_seq OWNER TO postgres;

--
-- Name: tb_pembayaran_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pembayaran_id_tagihan_seq OWNED BY tb_pembayaran.id_tagihan;


--
-- Name: tb_penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penggunaan (
    id_penggunaan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    bulan date,
    tahun date,
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE tb_penggunaan OWNER TO postgres;

--
-- Name: tb_penggunaan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_penggunaan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_penggunaan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tb_penggunaan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_penggunaan_id_pelanggan_seq OWNED BY tb_penggunaan.id_pelanggan;


--
-- Name: tb_penggunaan_id_penggunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_penggunaan_id_penggunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_penggunaan_id_penggunaan_seq OWNER TO postgres;

--
-- Name: tb_penggunaan_id_penggunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_penggunaan_id_penggunaan_seq OWNED BY tb_penggunaan.id_penggunaan;


--
-- Name: tb_tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tagihan (
    id_tagihan integer NOT NULL,
    id_penggunaan integer NOT NULL,
    id_pelanggan integer NOT NULL,
    bulan date,
    tahun date,
    jumlah_meter integer,
    status character varying
);


ALTER TABLE tb_tagihan OWNER TO postgres;

--
-- Name: tb_tagihan_id_pelanggan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_tagihan_id_pelanggan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_tagihan_id_pelanggan_seq OWNER TO postgres;

--
-- Name: tb_tagihan_id_pelanggan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_tagihan_id_pelanggan_seq OWNED BY tb_tagihan.id_pelanggan;


--
-- Name: tb_tagihan_id_penggunaan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_tagihan_id_penggunaan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_tagihan_id_penggunaan_seq OWNER TO postgres;

--
-- Name: tb_tagihan_id_penggunaan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_tagihan_id_penggunaan_seq OWNED BY tb_tagihan.id_penggunaan;


--
-- Name: tb_tagihan_id_tagihan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_tagihan_id_tagihan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_tagihan_id_tagihan_seq OWNER TO postgres;

--
-- Name: tb_tagihan_id_tagihan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_tagihan_id_tagihan_seq OWNED BY tb_tagihan.id_tagihan;


--
-- Name: tb_tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_tarif (
    id_tarif integer NOT NULL,
    daya integer,
    tarifperkwh integer
);


ALTER TABLE tb_tarif OWNER TO postgres;

--
-- Name: tb_tarif_id_tarif_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_tarif_id_tarif_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_tarif_id_tarif_seq OWNER TO postgres;

--
-- Name: tb_tarif_id_tarif_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_tarif_id_tarif_seq OWNED BY tb_tarif.id_tarif;


--
-- Name: tb_admin id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin ALTER COLUMN id_admin SET DEFAULT nextval('tb_admin_id_admin_seq'::regclass);


--
-- Name: tb_admin id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin ALTER COLUMN id_level SET DEFAULT nextval('tb_admin_id_level_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Name: tb_pembayaran id_pembayaran; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran ALTER COLUMN id_pembayaran SET DEFAULT nextval('tb_pembayaran_id_pembayaran_seq'::regclass);


--
-- Name: tb_pembayaran id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran ALTER COLUMN id_tagihan SET DEFAULT nextval('tb_pembayaran_id_tagihan_seq'::regclass);


--
-- Name: tb_pembayaran id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran ALTER COLUMN id_pelanggan SET DEFAULT nextval('tb_pembayaran_id_pelanggan_seq'::regclass);


--
-- Name: tb_pembayaran id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran ALTER COLUMN id_admin SET DEFAULT nextval('tb_pembayaran_id_admin_seq'::regclass);


--
-- Name: tb_penggunaan id_penggunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penggunaan ALTER COLUMN id_penggunaan SET DEFAULT nextval('tb_penggunaan_id_penggunaan_seq'::regclass);


--
-- Name: tb_penggunaan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penggunaan ALTER COLUMN id_pelanggan SET DEFAULT nextval('tb_penggunaan_id_pelanggan_seq'::regclass);


--
-- Name: tb_tagihan id_tagihan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tagihan ALTER COLUMN id_tagihan SET DEFAULT nextval('tb_tagihan_id_tagihan_seq'::regclass);


--
-- Name: tb_tagihan id_penggunaan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tagihan ALTER COLUMN id_penggunaan SET DEFAULT nextval('tb_tagihan_id_penggunaan_seq'::regclass);


--
-- Name: tb_tagihan id_pelanggan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tagihan ALTER COLUMN id_pelanggan SET DEFAULT nextval('tb_tagihan_id_pelanggan_seq'::regclass);


--
-- Name: tb_tarif id_tarif; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tarif ALTER COLUMN id_tarif SET DEFAULT nextval('tb_tarif_id_tarif_seq'::regclass);


--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: tb_pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY tb_pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: tb_penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY tb_penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: tb_tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tb_tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2871.dat';

--
-- Data for Name: tb_tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tb_tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2867.dat';

--
-- Name: tb_admin_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_admin_id_admin_seq', 1, false);


--
-- Name: tb_admin_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_admin_id_level_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: tb_pembayaran_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pembayaran_id_admin_seq', 1, false);


--
-- Name: tb_pembayaran_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pembayaran_id_pelanggan_seq', 1, false);


--
-- Name: tb_pembayaran_id_pembayaran_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pembayaran_id_pembayaran_seq', 1, false);


--
-- Name: tb_pembayaran_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pembayaran_id_tagihan_seq', 1, false);


--
-- Name: tb_penggunaan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_penggunaan_id_pelanggan_seq', 1, false);


--
-- Name: tb_penggunaan_id_penggunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_penggunaan_id_penggunaan_seq', 1, false);


--
-- Name: tb_tagihan_id_pelanggan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_tagihan_id_pelanggan_seq', 1, false);


--
-- Name: tb_tagihan_id_penggunaan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_tagihan_id_penggunaan_seq', 1, false);


--
-- Name: tb_tagihan_id_tagihan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_tagihan_id_tagihan_seq', 1, false);


--
-- Name: tb_tarif_id_tarif_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_tarif_id_tarif_seq', 1, false);


--
-- Name: tb_admin tb_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin
    ADD CONSTRAINT tb_admin_pkey PRIMARY KEY (id_admin);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pembayaran tb_pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pembayaran
    ADD CONSTRAINT tb_pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: tb_penggunaan tb_penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penggunaan
    ADD CONSTRAINT tb_penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tb_tagihan tb_tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tagihan
    ADD CONSTRAINT tb_tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tb_tarif tb_tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_tarif
    ADD CONSTRAINT tb_tarif_pkey PRIMARY KEY (id_tarif);


--
-- PostgreSQL database dump complete
--

